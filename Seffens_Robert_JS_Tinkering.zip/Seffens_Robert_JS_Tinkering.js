function displayifChildIsAbleToRideTheRollerCoaster(){
    for(var childHeight= 51)
}
if (childHeight < 52){
    console.log("Get on the ride kiddo")
}
else{
    console.log("Sorry kiddo. Maybe Next year")
}